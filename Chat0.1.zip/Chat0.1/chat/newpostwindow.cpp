﻿#include "newpostwindow.h"
#include "ui_newpostwindow.h"
#include "constant.h"

NewPostWindow::NewPostWindow(QWidget *parent,tcpsocket *m, QString myid) :
    QDialog(parent),
    ui(new Ui::NewPostWindow)
{
    ui->setupUi(this);
    this->id = myid;
}

NewPostWindow::~NewPostWindow()
{
    delete ui;
}

QString NewPostWindow::getTitle(){
    return ui->titleEdit->text();
}

QString NewPostWindow::getContent(){
    return ui->contentEdit->toHtml();
}

bool NewPostWindow::isContentEmpty(){
    return ui->contentEdit->toPlainText().isEmpty();
}

// after click ok button send ID << title << content   to server

void NewPostWindow::on_buttonBox_accepted()
{

    QByteArray block;
    QDataStream out(&block,QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_8);

    out<<int(POST_BBS)<<id.toInt()<<this->getTitle()<<this->getContent();

}
